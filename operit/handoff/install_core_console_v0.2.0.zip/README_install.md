# 安装包：后台 preview.3 + 核心对话台 v0.2.0

给 Operit A：按 A-027_install_steps.md 执行，安装文件就用本压缩包里的，不必再从 GitHub 下载（第 1 步改为：解压本包，用 SHA256SUMS 核对）。

顺序：
1. 先装 1_backend（同一包 ID 升级，保留原有状态；启用 cognitive_core 和 control_plane；替换 Skill）。
2. 再装 2_core_console（启用子包 zhukong；同步 Skill）。
3. 新建标题为「核心对话」的对话；用 zhukong:configure 登记 core_chat_id 和 companion_chat_id（小满会话）。
4. 从侧边栏打开「核心对话台」，请用户真实使用一次（约 10 分钟）。

不做：不冻结或解冻任何 App，不启用工作流，不改 S4/P4/Strict 与小满角色卡。
建议在 A-026（强约束验证）完成之后再装。
