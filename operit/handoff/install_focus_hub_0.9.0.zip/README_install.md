安装：把 focus_hub-0.9.0.toolpkg 以包 ID local.focus_hub 升级安装（替换 0.8.0）。步骤见 A-030_steps.md，总计划见 00_plan.md。
