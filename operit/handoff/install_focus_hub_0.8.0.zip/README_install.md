# 主控台 0.8.0（Focus Hub 升级）

给 Operit A：按 A-029_steps.md 执行。安装文件就是本包里的 focus_hub-0.8.0.toolpkg（同一包 ID local.focus_hub，升级 0.7.0）。
不冻结、不改规则、不删对话和工作流。
