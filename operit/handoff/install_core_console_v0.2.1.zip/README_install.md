# 核心对话台 v0.2.1（修复安装失败）

上次 0.2.0 安装失败的原因：插件的界面注册写法不符合 Operit 注册阶段的规则（注册时引用 *.ui.js 只拿到占位函数，0.2.0 错误地去取了 .Screen）。0.2.1 已改为直接传入该引用，并加了模拟注册阶段的测试。

给 Operit A，接着 A-027 做：
1. 用 SHA256SUMS 核对两个文件。
2. 用 debug_install_toolpkg 安装 zhukong-0.2.1.toolpkg，启用子包 zhukong；用本包的 Skill 替换已复制的 zhukong Skill。
3. 继续 A-027 第 3 步（新建「核心对话」、configure 两个会话 ID、console_state 核对、打开核心对话台截图）和第 4 步（请用户真实使用）。
后台 preview.3 已装好，不要重装。不冻结、不启用工作流、不改规则。
